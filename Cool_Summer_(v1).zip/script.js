var counter = 0;

var img_carousel = document.getElementById("quality-afford");

// function carouselForward(){
//     counter = counter + 1;
//     $('.carousel1-slider').children().css('transform', 'translate(-'+counter+'00%)')
// }

function carouselForward(){
    var checkChild = img_carousel.children[2].style.transform;
    if (checkChild == 'translateX(-429%)') {
        $('.carousel1-slider').children().css('transform', 'translateX(-429%)')
    } else {
        percentage = (100*counter) + (29*counter);
        counter = counter + 1;
        $('.carousel1-slider').children().css('transform', 'translateX(-'+percentage+'%)')
    }
}

function carouselBackward(){
    var checkChild = img_carousel.children[2].style.transform;
    if (checkChild == 'translateX(0%)') {
        $('.carousel1-slider').children().css('transform', 'translateX(0%)')
    } else {
        percentage = (100*counter) - (29*counter);
        counter = counter - 1;
        $('.carousel1-slider').children().css('transform', 'translateX(-'+percentage+'%)')
    }
}
